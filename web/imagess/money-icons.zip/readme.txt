Money Icon Set 

License Agreement

By purchasing icons from Aha-Soft, You (the purchaser)
agree to the terms of this agreement, as detailed below. 

You may use the icons from Aha-Soft in commercial and
personal design projects, software or Internet products.
Icons can be displayed in documentation, help files, and
advertising materials. You are free to sell and distribute
products and projects using purchased icons without further
royalty fees. 

All icon files are provided 'as is'. Aha-Soft cannot be
held liable for any negative issues that may occur as a
result of using the icons. 

You agree that all ownership and copyright of the icons
remains the property of Aha-Soft. You may not resell,
distribute, lease, license or sub-license the icons or
modified icons (or a subset of the icons), to any third
party unless they are incorporated into your software or
design products. 

If you have any questions regarding copyright or licensing,
including whether another license is required for icon use
within products, please contact us here: www.aha-soft.com/support.htm 

Product page:
http://www.aha-soft.com/stock-icons/money-icons.htm

Download demo:
http://www.aha-soft.com/downloads/money-icons.zip
http://www.icon-files.com/downloads/money-icons.zip

Icon Design Service

We can design custom icons for you. Please find the basic information
about ordering icons, pricing and the portfolio here:
www.aha-soft.com/customdev/design.htm


Support page: http://www.aha-soft.com/support.htm

Copyright � 2000-2010 Aha-Soft. All rights reserved. 